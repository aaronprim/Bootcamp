import BoxGenerator from './components/BoxGenerator';

function App() {
  return (
    <div className="App">
      <BoxGenerator/>
    </div>
  );
}

export default App;
